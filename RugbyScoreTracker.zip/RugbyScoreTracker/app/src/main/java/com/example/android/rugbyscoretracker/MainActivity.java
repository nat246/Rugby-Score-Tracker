package com.example.android.rugbyscoretracker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
   int scoreHome;
   int homeTries;
   int homePenalties;
   int homeConversions;
   int homeDG;

   int scoreAway;
   int awayTries;
   int awayPenalties;
   int awayConversions;
   int awayDG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /** AWAY TEAM */

    /**adds point to Try to Away team*/
    public void addPointAwayTry (View view) {
        awayTries = awayTries + 1;
        scoreAway = scoreAway + 5;
        displayAwayTryPoints(awayTries);
        displayAwayScore(scoreAway);
    }
    /**adds point to Penalty to Away team*/
    public void addPointAwayPenalty (View view) {
        awayPenalties = awayPenalties + 1;
        scoreAway = scoreAway + 3;
        displayAwayPenaltyPoints(awayPenalties);
        displayAwayScore(scoreAway);
    }
    /**adds point to Conversions to Away team*/
    public void addPointAwayConversion (View view) {
        awayConversions = awayConversions + 1;
        scoreAway = scoreAway + 2;
        displayAwayConversionPoints(awayConversions);
        displayAwayScore(scoreAway);
    }
    /**adds point to Drop Goals to Away team*/
    public void addPointAwayDG (View view) {
        awayDG = awayDG + 1;
        scoreAway = scoreAway + 3;
        displayAwayDgPoints(awayDG);
        displayAwayScore(scoreAway);
    }

    /** HOME TEAM */

    /**adds point to Try to Home team*/
    public void addPointHomeTry (View view) {
        homeTries = homeTries + 1;
        scoreHome = scoreHome + 5;
        displayHomeTryPoints(homeTries);
        displayHomeScore(scoreHome);
    }
    /**adds point to Penalty to Home team*/
    public void addPointHomePenalty (View view) {
        homePenalties = homePenalties + 1;
        scoreHome = scoreHome + 3;
        displayHomePenaltyPoints(homePenalties);
        displayHomeScore(scoreHome);
    }
    /**adds point to Conversions to Home team*/
    public void addPointHomeConversion (View view) {
        homeConversions = homeConversions + 1;
        scoreHome = scoreHome + 2;
        displayHomeConversionPoints(homeConversions);
        displayHomeScore(scoreHome);
    }
    /**adds point to Drop Goals to Home team*/
    public void addPointHomeDG (View view) {
        homeDG = homeDG + 1;
        scoreHome = scoreHome + 3;
        displayHomeDgPoints(homeDG);
        displayHomeScore(scoreHome);
    }

    /** RESET */

    /** Resets the tracker */
    public void resetScores (View view) {
        scoreHome = 0;
        homeTries = 0;
        homePenalties = 0;
        homeConversions = 0;
        homeDG = 0;

        scoreAway = 0;
        awayTries = 0;
        awayPenalties = 0;
        awayConversions = 0;
        awayDG = 0;

        displayHomeScore(scoreHome);
        displayHomeTryPoints(homeTries);
        displayHomePenaltyPoints(homePenalties);
        displayHomeConversionPoints(homeConversions);
        displayHomeDgPoints(homeDG);

        displayAwayScore(scoreAway);
        displayAwayTryPoints(awayTries);
        displayAwayPenaltyPoints(awayPenalties);
        displayAwayConversionPoints(awayConversions);
        displayAwayDgPoints(awayDG);
    }

    /**
     * Displays the given points and score for Home team.
     */
    /** Displays overall Home score */
    public void displayHomeScore(int score) {
        TextView scoreView = (TextView) findViewById(R.id.home_score);
        scoreView.setText(String.valueOf(score));
    }
    /** Displays number of Tries of Home team */
    public void displayHomeTryPoints(int score) {
        TextView scoreView = (TextView) findViewById(R.id.numberOfHomeTries);
        scoreView.setText(String.valueOf(score));
    }
    /** Displays number of Penalties of Home team */
    public void displayHomePenaltyPoints(int score) {
        TextView scoreView = (TextView) findViewById(R.id.numberOfHomePenalties);
        scoreView.setText(String.valueOf(score));
    }
    /** Displays number of Conversions of Home team  */
    public void displayHomeConversionPoints(int score) {
        TextView scoreView = (TextView) findViewById(R.id.numberOfHomeConversions);
        scoreView.setText(String.valueOf(score));
    }
    /** Displays number of Drop Goals of Home team */
    public void displayHomeDgPoints(int score) {
        TextView scoreView = (TextView) findViewById(R.id.numberOfHomeDG);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Displays the given points and score for Away team.
     */

    /** Display overall Away score*/
    public void displayAwayScore(int score) {
        TextView scoreView = (TextView) findViewById(R.id. away_score);
        scoreView.setText(String.valueOf(score));
    }
    /** Displays number of Tries of Away team */
    public void displayAwayTryPoints(int score) {
        TextView scoreView = (TextView) findViewById(R.id.numberOfAwayTries);
        scoreView.setText(String.valueOf(score));
    }
    /** Displays number of Penalties of Away team */
    public void displayAwayPenaltyPoints(int score) {
        TextView scoreView = (TextView) findViewById(R.id.numberOfAwayPenalties);
        scoreView.setText(String.valueOf(score));
    }
    /** Displays number of Conversions of Away team */
    public void displayAwayConversionPoints(int score) {
        TextView scoreView = (TextView) findViewById(R.id.numberOfAwayConversions);
        scoreView.setText(String.valueOf(score));
    }
    /** Displays number of Drop Goals of Away team */
    public void displayAwayDgPoints(int score) {
        TextView scoreView = (TextView) findViewById(R.id.numberOfAwayDG);
        scoreView.setText(String.valueOf(score));
    }
}
